#include <iostream>
#include <cassert>
#include <limits.h>
#include <stdlib.h>
#include <stack> 
#include <set>
#include <vector> 
#include <fstream>
#include <cstring>
#include <string>

#define WHITE 0
#define GREY 1
#define BLACK 2
//#define RED 3

#define OK -1

#define VERTEX(u) G[u].v
#define COLOR(u) G[u].color
#define OUT_DEG(u) G[u].out_degree
#define IN_DEG(u) G[u].in_degree
#define P(u) G[u].p
#define COUNTER(u) G[u].counter
#define LOWLINK(u) G[u].lowlink
#define START_VISIT(u) G[u].t_start
#define END_VISIT(u) G[u].t_finish
#define DIST(u) G[u].s_dist
#define ONSTACK(u) G[u].on_stack

#define ADJ(u, v) G[u].adj_list[v]
#define ADJ_INDEX(u,v) map[G[u].adj_list[v]]

#define INC(u, v) G[u].inc_list[v]

#define FOR_EACH_VERTEX for(int i = 0; i < V; i++)
#define FOR_EACH_EDGE for(int i = 0; i < E; i++)
#define FOR_EACH_ADJ(u)                         \
        for(int v = 0; v < OUT_DEG(u); v++) 
#define FOR_EACH_INC(u) for(int k = 0; k < IN_DEG(u); k++)

#define ALLOC(type, length) (type*) malloc(sizeof(type) * (length))
#define REALLOC(who, type, length) who = (type*) realloc(who, sizeof(type) * (length))

#define DEBUG 

// Rappresenta un arco.
struct arco_t
{
    int dest; // Testa dell'arco.
    int c; // Capacità dell'arco.
    int f; // Flusso assegnato.
    arco_t(int dest, int c);
    ~arco_t();
};

arco_t::arco_t(int dest, int c)
{
    this->dest = dest;
    this->c = c;
    this->f = 0;
}

arco_t::~arco_t()
{}



//dimensioni del grafo
int V, E;

// La rete iniziale.
//vector<arco_t> rete[];
// Grafo della rete residua trasposta.
//vector<arco_t> residua[];

using namespace std;

ifstream input;
ofstream output;

//struttura di un vertice
typedef struct vertex_struct {
    int v;          //nome del vertice
    int in_degree;  //grado di archi entranti
    int out_degree; //grado di archi uscenti
    int color;      //colore del vertice durante la visita
    int p;          //padre del vertice
    int counter;    //contatore ci serve per identificare componenti connesse
    int lowlink;    //contatore ci serve per identificare componenti connesse
    int on_stack;   //identifica se il vertice è nello stack
    int s_dist;     //distanza dalla sorgente
    int t_start;    //tempo di inizio della visita del vertice
    int t_finish;   //tempo di fine della visita del vertice
    int *adj_list;  //lista di adiacenza del vertice
    int *inc_list;  //lista di incidenza del vertice
} vertex_t;

typedef vertex_t* graph_t;

typedef graph_t tree_t;

int T = 0; //contatore del tempo di visita della DFS

graph_t G;
int *map;
int consiglieri = 0;
int counter = 0;
stack<int> S;

void print_tree() {
    //cout << consiglieri << endl;
    output << consiglieri << endl;
    FOR_EACH_VERTEX {
        if(P(i) == -1) {
            #ifdef DEBUG
            cout << VERTEX(i) << " ";
            #endif
            output << VERTEX(i) << " ";

        }
        
    }
    //cout << endl;
    output << endl;
    FOR_EACH_VERTEX {
        if(P(i) != -1) {
            #ifdef DEBUG
            cout << P(i)<< " " << VERTEX(i) << endl;
            #endif
            output << P(i)<< " " << VERTEX(i) << endl;
        }
    }
}

int min(int a, int b) {
    return (a < b) ? a : b;
}

int DFS_visit(int u) {
    COLOR(u) = GREY; //coloro il nodo a grigio
    START_VISIT(u) = T; //setto il tempo di inizio visita
    COUNTER(u) = counter;
    LOWLINK(u) = counter;
    S.push(u);
    ONSTACK(u) = 1;
    counter++;
    #ifdef DEBUG
    cout << "T:" << T << " --\tSTART VISIT OF " << VERTEX(u) << " counter(u): " << COUNTER(u) << " lowlink(u): " << LOWLINK(u) << endl;
    #endif
    T++;
    //scorro la lista di adiacenza per visitare tutti gli archi che partono dal noodo
    FOR_EACH_ADJ(u) {
        int w = ADJ_INDEX(u, v);
        #ifdef DEBUG
        cout << "\t\tvisit edge from " << VERTEX(u) << " to " << VERTEX(w) << endl;
        cout << "\t\tBefore visit\tu = " << VERTEX(u) << "\tw = " << VERTEX(w) << endl;
        cout << "\t\tlowlink(w): " << LOWLINK(w) << " counter(w): " << COUNTER(w) << endl;
        cout << "\t\tlowlink(u): " << LOWLINK(u) << " counter(u): " << COUNTER(u) << endl << endl;
        cout << "\t\tcolor(w) is ";
        #endif
        //se trovo un nodo bianco lo setto come mio sottoposto e lo visito
        if(COLOR(w) == WHITE) {
            
            P(w) = VERTEX(u);
            #ifdef DEBUG
            cout << "WHITE" << endl;
            cout << "\t\t\tset " << VERTEX(u) << " as father of " << VERTEX(w) << endl;
            #endif
            DFS_visit(w);
            LOWLINK(u) = min(LOWLINK(u), LOWLINK(w));
            
        
        //se trovo un nodo grigio allora ho trovato un ciclo
        } else if(ONSTACK(w) == 1) {

            LOWLINK(u) = min(LOWLINK(u), COUNTER(w));

        } else if(COLOR(w) == BLACK && P(w) == -1 /*&& END_VISIT(w) < START_VISIT(u)*/) {
            int found = 0;
            #ifdef DEBUG
            cout << "BLACK" << endl;
            #endif
            //se sono il padre di w
            //scorro la lista di adj di u da w in poi
            for(int i = 0; i < OUT_DEG(u); i++) {
                int z = ADJ_INDEX(u, i);
                #ifdef DEBUG
                cout << "\t\titerator i: " << i << " z: " << VERTEX(z) << " lowlink(z): " << LOWLINK(z) << endl;
                #endif
                //se trovo un nodo con la stessa componente connessa di w lo stacco da u e diventa consigliere
                if(LOWLINK(w) == LOWLINK(z) && P(z) == VERTEX(u) && VERTEX(w)!=VERTEX(z)) {
                    found = 1;
                    #ifdef DEBUG
                    cout << "\t\t vertex" << VERTEX(z) << " found " << "in_deg(z): " << IN_DEG(z) << endl;
                    #endif
                    if(IN_DEG(w) < IN_DEG(z)) {
                        #ifdef DEBUG
                        cout << "\t\ttook w (IN_DEG(w): "<< IN_DEG(w) << " ) instead of z" << endl;
                        #endif
                        P(w) = VERTEX(u);
                        P(z) = -1;
                        IN_DEG(z)--;
                    }
                }
                
            }
            if(found == 0){
                if(P(w) == -1)
                    consiglieri--;
                P(w) = VERTEX(u);
                #ifdef DEBUG
                cout << "\t\t" << VERTEX(w) << " took as son" << endl;
                #endif
            }
            

        }

        #ifdef DEBUG
        cout << "\t\tAfter visit\tu = " << VERTEX(u) << "\tw = " << VERTEX(w) << endl;
        cout << "\t\tlowlink(w): " << LOWLINK(w) << " counter(w): " << COUNTER(w) << endl;
        cout << "\t\tlowlink(u): " << LOWLINK(u) << " counter(u): " << COUNTER(u) << endl << endl;
        #endif



    }

    int w, z;

    //controllo le componenti connesse
    if(LOWLINK(u) == COUNTER(u)) {
        #ifdef DEBUG
        cout << "\t\tFound cycle starting in " << VERTEX(u) << endl;
        #endif
        rete = ALLOC(arco_t,V+2);
        residua = ALLOC(arco_t,V+2);
        int s = 0; //inizializzo la sorgente per maximum matching
        int t = 1; //inizializzo la destinazione per maximum matching
        do{
            w = S.top();
            S.pop();
            ONSTACK(w) = 0;
            #ifdef DEBUG
            cout << "\t\tindex of u: " << u << " index of w: " << w << endl;
            cout << "\t\t" << VERTEX(w) << " is out stack";
            #endif

            // Inizializzo la rete per maximum matching
            rete[s].push_back(arco_t(w+2,1));
            // Inizialmente la rete residua è il trasposto della rete.
            residua[w+2].push_back(arco_t(s,1));
            FOR_EACH_INC(w){
                rete[w+2].push_back(arco_t(k+2,1));
                residua[k+2].push_back(arco_t(w+2,1));
                rete[k+2].push_back(arco_t(t,1));
                residua[t].push_back(arco_t(k+2,1));
            }

            if(w != u) {
                if(P(w) != -1)
                    consiglieri++;
                P(w) = -1;
                LOWLINK(w) = LOWLINK(u);
                #ifdef DEBUG
                cout << " and consigliere" << endl;
                #endif
            } 
            #ifdef DEBUG
            else 
                cout << endl;
            #endif
            
        } while(w != u);

    }
    #ifdef DEBUG
    cout << endl << "\t\tchecking third law for " << VERTEX(u) << endl;
    #endif



    //visita terminata

    COLOR(u) = BLACK;


    END_VISIT(u) = T;
    #ifdef DEBUG
    cout << "\t\tset " << VERTEX(u) << " to BLACK" << endl;
    cout << "T:" << T << " --\tEND VISIT OF " << VERTEX(u) << endl;
    #endif
    T++;
    
    return -1;
}

void DFS() {
    FOR_EACH_VERTEX {
        if(COLOR(i) == WHITE) {
            consiglieri++;
            DFS_visit(i);
        }
    }
    return;
}

int partition( vertex_t* v, int l, int r) {
   int pivot, i, j;
   vertex_t t;
   pivot = v[l].in_degree;
   i = l; j = r+1;
        
   while( 1)
   {
    do ++i; while( v[i].in_degree <= pivot && i <= r );
    do --j; while( v[j].in_degree > pivot );
    if( i >= j ) break;
    t = v[i]; v[i] = v[j]; v[j] = t;
   }
   t = v[l]; v[l] = v[j]; v[j] = t;
   return j;
}

void quickSort( vertex_t* v, int l, int r)
{
   int j;

   if( l < r ) 
   {
       j = partition( v, l, r);
       quickSort( v, l, j-1);
       quickSort( v, j+1, r);
   }
    
}



int main() {

    

    //apro il file di input e di output
    input.open("input.txt");
    assert(input.is_open());
    output.open("output.txt", ofstream::trunc);

    //leggo numero nodi e archi
    input >> V;
    input >> E;

    //alloco spazio per i vertici
    graph_t g = ALLOC(vertex_t, V);

    G = g;

    //inizializzo i vertici
    FOR_EACH_VERTEX {
        VERTEX(i) = i;
        IN_DEG(i) = 0;
        OUT_DEG(i) = 0;
        COLOR(i) = WHITE;
        P(i) = -1;
        COUNTER(i) = -1;
        LOWLINK(i) = -1;
        DIST(i) = 0;
        ONSTACK(i) = 0;
        START_VISIT(i) = -1;
        END_VISIT(i) = -1;
    }
    

    int u, v;

    /*####################  leggo il grafo  #######################*/
    FOR_EACH_EDGE { //per ogni arco

        //leggo il nome dei nodi dell'arco
        input >> u;
        input >> v;

        //se non ho già la lista di adiacenza per u allora la creo
        if(OUT_DEG(u) == 0) {
            G[u].adj_list = ALLOC(int, 1);
        } else {    // altrimenti aumento il suo spazio
            REALLOC(G[u].adj_list, int, OUT_DEG(u)+1);
        }
        ADJ(u, OUT_DEG(u)) = v;     //metto il vertice di arrivo nella lista di adj di u

        //se non ho già la lista di incidenza per v allora la creo
        if(IN_DEG(v) == 0){
            G[v].inc_list = ALLOC(int, 1);
        } else {    // altrimenti aumento il suo spazio
            REALLOC(G[v].inc_list, int, IN_DEG(v)+1);
        }
        INC(v, IN_DEG(v)) = u;     //metto il vertice di partenza nella lista di incidenza di v

        OUT_DEG(u)++;               //aumento il numero di archi uscenti da u
        IN_DEG(v)++;                //aumento l'in degree di v

    }

    //quickSort(G, 0, V-1);
    

    map = ALLOC(int, V);

    FOR_EACH_VERTEX {
        map[VERTEX(i)] = i;
    }

    DFS();

    print_tree();

    return 0;
}